import {
    BrowserRouter as Router,
    Route,
    Routes,
    Link
} from "react-router-dom";
import React from "react";
import './App.css';
import Header from "./Components/layout/Header";

function App() {
  return (
    <div className="App">
        <div id="wrapper">
            <Header />

        </div>
    </div>
  );
}

export default App;
