import React from "react";


const Logo=(props)=>{

    return(
        <div className="logo">
            <a href="/">
                <img src="images/logo.png" alt="logo" />
            </a>
        </div>
    )
}

export default Logo;
