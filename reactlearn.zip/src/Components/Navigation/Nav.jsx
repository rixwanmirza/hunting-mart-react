import React  from "react";
import ReactDOM from 'react-dom';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    useRouteMatch,
    useParams, Routes
} from "react-router-dom";


const Nav=(props)=>{
    return(
        <nav id="nav">
            <ul>
                <li>
                    <a href="/">Home</a>
                </li>
            </ul>
        </nav>


    )
}

export default Nav;
